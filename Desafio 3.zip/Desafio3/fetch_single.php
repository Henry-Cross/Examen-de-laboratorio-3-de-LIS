<?php
include('db.php');
include('function.php');
if(isset($_POST["id"]))
{
	$output = array();
	$statement = $connection->prepare(
		"SELECT * FROM recetas 
		WHERE id = '".$_POST["id"]."' 
		LIMIT 1"
	);
	$statement->execute();
	$result = $statement->fetchAll();
	foreach($result as $row)
	{
		$output["Nombre"] = $row["Nombre"];
		$output["Tipo"] = $row["Tipo"];
		$output["Ingredientes"] = $row["Ingredientes"];
		$output["Preparacion"] = $row["Preparacion"];
		if($row["Imagen"] != '')
		{
			$output['Imagen'] = '<img src="upload/'.$row["Imagen"].'" class="img-thumbnail" width="50" height="35" /><input type="hidden" name="hidden_Imagen" value="'.$row["Imagen"].'" />';
		}
		else
		{
			$output['Imagen'] = '<input type="hidden" name="hidden_Imagen" value="" />';
		}
	}
	echo json_encode($output);
}
?>