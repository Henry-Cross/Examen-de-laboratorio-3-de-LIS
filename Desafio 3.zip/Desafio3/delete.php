<?php

include('db.php');
include("function.php");

if(isset($_POST["id"]))
{
	$Imagen = get_image_name($_POST["id"]);
	if($Imagen != '')
	{
		unlink("upload/" . $Imagen);
	}
	$statement = $connection->prepare(
		"DELETE FROM recetas WHERE id = :id"
	);
	$result = $statement->execute(
		array(
			':id'	=>	$_POST["id"]
		)
	);
	
	if(!empty($result))
	{
		echo 'Registro eliminado';
	}
}



?>