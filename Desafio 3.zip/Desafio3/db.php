<?php

$username = 'root';
$password = '';
$connection = new PDO( 'mysql:host=localhost;dbname=recetas', $username, $password );

?>