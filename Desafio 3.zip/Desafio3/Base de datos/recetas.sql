-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Servidor: 127.0.0.1:3306
-- Tiempo de generación: 06-05-2021 a las 01:39:58
-- Versión del servidor: 5.7.31
-- Versión de PHP: 7.3.21

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Base de datos: `recetas`
--

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `recetas`
--

DROP TABLE IF EXISTS `recetas`;
CREATE TABLE IF NOT EXISTS `recetas` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `Nombre` varchar(150) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `Tipo` varchar(150) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `Ingredientes` varchar(1000) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `Preparacion` varchar(1000) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `Imagen` varchar(150) COLLATE utf8mb4_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

--
-- Volcado de datos para la tabla `recetas`
--

INSERT INTO `recetas` (`id`, `Nombre`, `Tipo`, `Ingredientes`, `Preparacion`, `Imagen`) VALUES
(9, 'AlbÃ³ndigas de pollo', 'Plato Principal', '500 gr de carne de pollo molida 1 taza de polvo de pan 1 cebolla picada finamente 1 diente de ajo picado Â¾ de taza de leche 4 hojas de hierbabuena picada 1 cdita de sal de ajo 1 huevo ligeramente batido Â¼ de taza de caldo de pollo 3 cdas de pasta de tomate Sal y pimienta al gusto', 'Agrega la leche a las migas de pan. SofrÃ­e la cebolla y el ajo en una sartÃ©n, agrega la miga de pan con leche, sal de ajo, hierbabuena y pimienta. Mezcla aparte con la carne molida y forma las albÃ³ndigas. DÃ³ralas en aceite caliente. Mientras, prepara la salsa de tomate con caldo de pollo; cuando estÃ© hirviendo agrega las albÃ³ndigas y cocÃ­nelas unos minutos mÃ¡s. Â¡Buen provecho!', '310315368.jpg'),
(10, 'Arroz con pollo', 'Plato Principal', '1 kg de pollo 500 gr de arroz 1 zanahoria Â½ cebolla 3 dientes de ajo Â½ pimiento rojo 1 rama de cilantro 3 tazas de caldo de pollo Sal Pimienta Comino', 'AÃ±adir en una licuadora el caldo de pollo y las ramas de cilantro. Cortar la zanahoria, cebolla, ajos y pimiento rojo, en trozos muy pequeÃ±os. Cortar el pollo en trozos medianos y condimentar con sal, pimienta y comino. Colocar estos trozos en un sartÃ©n caliente aceitado y sellarlos, hasta quedar dorados. En una olla agregar la cebolla y ajo picados, con un poco de aceite, y sofreÃ­r hasta ablandar la cebolla. Posteriormente agregar 1 taza de arroz y sofreÃ­rlo. AÃ±adir el picadillo de zanahoria y pimientos rojos, y revolver. Adicionar la mezcla de la licuadora de caldo de pollo y cilantro, ademÃ¡s los trozos de pollo ya picados y dorados, revolver bien. Colocar la tapa de la olla, a fuego lento hasta observar la cocciÃ³n, y estarÃ¡ listo.', '1084154012.jpg'),
(11, 'pupusas', 'Entrada', 'Â½ lb masa de maÃ­z molido Agua Sal al gusto Relleno: queso, frijoles, pollo, carne (opcionales)', 'Antes de preparar la masa, se debe disponer la plancha y se unta un poco de aceite para evitar que las pupusas se peguen. Se prepara la harina, la cual se revuelve con agua tibia para formar la masa. Se amasa lo suficiente, y le damos la forma de una tortilla. Al estar listo, colocamos las puposas en la plancha por aproximadamente 5 minutos. En una mesa, colocamos las puposas junto a los ingredientes que gusten para acompaÃ±arlas. Por general se agrega queso, frijoles, carne, pollo. Queda a su gusto.   No debe agregar mucho relleno, ya que la masa debe cerrar y no queremos que los ingredientes rebosen. Esta entrada debe acompaÃ±arse de un curtido o salsa de tomate. Listo. Nos disponemos a degustar.', '1858812786.jpg');

-- --------------------------------------------------------

--
-- Estructura de tabla para la tabla `usuarios`
--

DROP TABLE IF EXISTS `usuarios`;
CREATE TABLE IF NOT EXISTS `usuarios` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `correo` varchar(150) COLLATE utf8mb4_spanish2_ci NOT NULL,
  `password` varchar(150) COLLATE utf8mb4_spanish2_ci NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_spanish2_ci;

--
-- Volcado de datos para la tabla `usuarios`
--

INSERT INTO `usuarios` (`id`, `correo`, `password`) VALUES
(1, 'henrylopez1998.hfl@gmail.com', '$2y$10$gAxySYgs5Rrwiqr9DVL.cuNA9aOjQGCItkNkpprhIjoJSVnWZqaf2'),
(2, 'henrylopez1998.hfl@gmail.com', '$2y$10$RKV5Ya7Yym3q94ctDZozwOMKbga7rUy3k1F4h4es36IZUfFWtwNiC');
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
