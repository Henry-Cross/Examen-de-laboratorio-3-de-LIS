<?php
include('db.php');
include('function.php');
if(isset($_POST["operation"]))
{
	if($_POST["operation"] == "Add")
	{
		$image = '';
		if($_FILES["Imagen"]["name"] != '')
		{
			$image = upload_image();
		}
		$statement = $connection->prepare("
			INSERT INTO recetas (Nombre, Tipo,Ingredientes,Preparacion, Imagen) 
			VALUES (:Nombre, :Tipo, :Ingredientes, :Preparacion, :Imagen)
		");
		$result = $statement->execute(
			array(
				':Nombre'	=>	$_POST["Nombre"],
				':Tipo'	=>	$_POST["Tipo"],
				':Ingredientes'	=>	$_POST["Ingredientes"],
				':Preparacion'	=>	$_POST["Preparacion"],
				':Imagen'		=>	$image
			)
		);
		if(!empty($result))
		{
			echo 'Datos ingresados';
		}
	}
	if($_POST["operation"] == "Edit")
	{
		$image = '';
		if($_FILES["Imagen"]["name"] != '')
		{
			$image = upload_image();
		}
		else
		{
			$image = $_POST["hidden_Imagen"];
		}
		$statement = $connection->prepare(
			"UPDATE recetas 
			SET Nombre = :Nombre, Tipo = :Tipo, Ingredientes = :Ingredientes, Preparacion = :Preparacion, Imagen = :Imagen  
			WHERE id = :id
			"
		);
		$result = $statement->execute(
			array(
				':Nombre'	=>	$_POST["Nombre"],
				':Tipo'	=>	$_POST["Tipo"],
				':Ingredientes'	=>	$_POST["Ingredientes"],
				':Preparacion'	=>	$_POST["Preparacion"],
				':Imagen'		=>	$image,
				
				':id'			=>	$_POST["id"]
			
			)
		);
		if(!empty($result))
		{
			echo 'Datos actualizados';
		}
	}
}

?>