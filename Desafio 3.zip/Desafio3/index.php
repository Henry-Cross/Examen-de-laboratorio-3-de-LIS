<html>
	<head>
		<title>CRUD DESAFIO 3</title>
		<script src="https://ajax.googleapis.com/ajax/libs/jquery/2.2.0/jquery.min.js"></script>
		<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />
		<script src="https://cdn.datatables.net/1.10.12/js/jquery.dataTables.min.js"></script>
		<script src="https://cdn.datatables.net/1.10.12/js/dataTables.bootstrap.min.js"></script>		
		<link rel="stylesheet" href="https://cdn.datatables.net/1.10.12/css/dataTables.bootstrap.min.css" />
		<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/js/bootstrap.min.js"></script>
		<style>
			body
			{
				margin:0;
				padding:0;
				background-color:#f1f1f1;
			}
			.box
			{
				width:1270px;
				padding:20px;
				background-color:#fff;
				border:1px solid #ccc;
				border-radius:5px;
				margin-top:25px;
			}
		</style>
	</head>
	<body>
		<div class="container box">
			<h1 align="center">Recetas Caseras</h1>
			<br />
			<div class="table-responsive">
				<br />
				<?php
				error_reporting(0);
  session_start();

  require 'database.php';

  if (isset($_SESSION['user_id'])) {
    $records = $conn->prepare('SELECT id, correo, password FROM usuarios WHERE id = :id');
    $records->bindParam(':id', $_SESSION['user_id']);
    $records->execute();
    $results = $records->fetch(PDO::FETCH_ASSOC);

    $user = null;

    if (count($results) > 0) {
      $user = $results;
    }
  }
?>
			

<?php if(!empty($user)): ?>
  <br> Bienvenido. <?= $user['correo']; ?>
  <br>Ingresaste correctamente
  <a href="logout.php">
	Salir
  </a>
<?php else: ?>
  <h1>Por favor inicia sesión o registrate</h1>

  <a href="login.php">Iniciar sesión</a> o
  <a href="signup.php">Registrarse</a>
<?php endif; ?>
				<div align="right">
					<button type="button" id="add_button" data-toggle="modal" data-target="#userModal" class="btn btn-info btn-lg">Agregar nueva receta</button>
				</div>
				<br /><br />
				<table id="user_data" class="table table-bordered table-striped">
					<thead>
						<tr>
							<th width="10%">Imagen</th>
							<th width="35%">Nombre</th>
							<th width="35%">Categoria</th>
							<th width="35%">Ingredientes</th>
							<th width="35%">Preparacion</th>
							<th width="10%">Editar</th>
							<th width="10%">Eliminar</th>
						</tr>
					</thead>
				</table>
				
			</div>
		</div>
	</body>
</html>

<div id="userModal" class="modal fade">
	<div class="modal-dialog">
		<form method="post" id="user_form" enctype="multipart/form-data">
			<div class="modal-content">
				<div class="modal-header">
					<button type="button" class="close" data-dismiss="modal">&times;</button>
					<h4 class="modal-title">Agregar nueva receta</h4>
				</div>
				<div class="modal-body">
					<label>Nombre</label>
					<input type="text" name="Nombre" id="Nombre" class="form-control" />
					<br />
					<label>Tipo</label>
					<input type="text" name="Tipo" id="Tipo" class="form-control" />
					<br />
					<label>Ingredientes</label>
					<input type="text" name="Ingredientes" id="Ingredientes" class="form-control" />
					<br />
					<label>preparacion</label>
					<input type="text" name="Preparacion" id="Preparacion" class="form-control" />
					<br />

					<label>Imagen</label>
					<input type="file" name="Imagen" id="Imagen" />
					<span id="Imagensubida"></span>
				</div>
				<div class="modal-footer">
					<input type="hidden" name="id" id="id" />
					<input type="hidden" name="operation" id="operation" />
					<input type="submit" name="action" id="action" class="btn btn-success" value="Add" />
					<button type="button" class="btn btn-default" data-dismiss="modal">Cerrar</button>
				</div>
			</div>
		</form>
	</div>
</div>

<script type="text/javascript" language="javascript" >
$(document).ready(function(){
	$('#add_button').click(function(){
		$('#user_form')[0].reset();
		$('.modal-title').text("Add User");
		$('#action').val("Agregar");
		$('#operation').val("Add");
		$('#Imagensubida').html('');
	});
	
	var dataTable = $('#user_data').DataTable({
		"processing":true,
		"serverSide":true,
		"order":[],
		"ajax":{
			url:"fetch.php",
			type:"POST"
		},
		"columnDefs":[
			{
				"targets":[0, 3, 4],
				"orderable":false,
			},
		],

	});

	$(document).on('submit', '#user_form', function(event){
		event.preventDefault();
		var Nombre = $('#Nombre').val();
		var Tipo = $('#Tipo').val();
		var Ingredientes = $('#Ingredientes').val();
		var Preparacion = $('#Preparacion').val();
		var extension = $('#Imagen').val().split('.').pop().toLowerCase();
		if(extension != '')
		{
			if(jQuery.inArray(extension, ['gif','png','jpg','jpeg']) == -1)
			{
				alert("Imagen invalida");
				$('#Imagen').val('');
				return false;
			}
		}	
		if(Nombre != '' && Tipo != '' && Ingredientes != ''&& Preparacion != '')
		{
			$.ajax({
				url:"insert.php",
				method:'POST',
				data:new FormData(this),
				contentType:false,
				processData:false,
				success:function(data)
				{
					alert(data);
					$('#user_form')[0].reset();
					$('#userModal').modal('hide');
					dataTable.ajax.reload();
				}
			});
		}
		else
		{
			alert("Todos los datos son necesarios");
		}
	});
	
	$(document).on('click', '.update', function(){
		var id = $(this).attr("id");
		$.ajax({
			url:"fetch_single.php",
			method:"POST",
			data:{id:id},
			dataType:"json",

			success:function(data)
		
			{
				$('#userModal').modal('show');
				$('#Nombre').val(data.Nombre);
				$('#Tipo').val(data.Tipo);
				$('#Ingredientes').val(data.Ingredientes);
				$('#Preparacion').val(data.Preparacion);
				$('.modal-title').text("Editar receta");
				$('#id').val(id);
				$('#Imagensubida').html(data.Imagen);
				$('#action').val("Editar");
				$('#operation').val("Edit");
				
			
			}
			
		})
	});
	
	$(document).on('click', '.delete', function(){
		var id = $(this).attr("id");
		if(confirm("¿Esta seguro que desea eliminar la receta?"))
		{
			$.ajax({
				url:"delete.php",
				method:"POST",
				data:{id:id},
				success:function(data)
				{
					alert(data);
					dataTable.ajax.reload();
				}
			});
		}
		else
		{
			return false;	
		}
	});
	
	
});
</script>
